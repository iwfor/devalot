module Fun::PDFHelper
  def foobar() 'baz' end
end
