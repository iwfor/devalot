require File.dirname(__FILE__) + '/kernel/daemonizing'
require File.dirname(__FILE__) + '/kernel/reporting'
require File.dirname(__FILE__) + '/kernel/agnostics'
require File.dirname(__FILE__) + '/kernel/requires'
